/**
 * 
 */
package account;

/**
 * @author rohini
 */
public interface AccountInterface {
	
	public String getAccountId();
	public String getAccountname();
	public String getAccountEmail();
	public long getAccountPhoneNumber();
	
}