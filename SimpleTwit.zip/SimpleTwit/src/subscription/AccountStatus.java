package subscription;

public enum AccountStatus {
	FREE_TRIAL,
	SUSPENDED,
	ACTIVE,
	CLOSED
}
