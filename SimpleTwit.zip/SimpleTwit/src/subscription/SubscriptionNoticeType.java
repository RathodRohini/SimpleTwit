package subscription;

public enum SubscriptionNoticeType {
	REACTIVATED,
	DEACTIVATED,
	CLOSED,
	UPCOMING_INVOICE
}
