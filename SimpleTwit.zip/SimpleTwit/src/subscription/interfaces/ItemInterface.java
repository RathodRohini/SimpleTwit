package subscription.interfaces;

public interface ItemInterface {
	public void setQuantity(long quantity);
	public long getQuantity();
	public void setUnit(String unit);
	public String getUnit();
}
