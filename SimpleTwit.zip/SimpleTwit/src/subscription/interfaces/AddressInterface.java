package subscription.interfaces;

public interface AddressInterface {
	//public void setFirstName(String firstName);
	public String getFirstName();
	//public void setLastName(String lastName);
	public String getLastName();
//	public void setFullName(String fullName);
	public String getFullName();
//	public void setStreet1(String streets);
	public String getStreet1();
//	public void setZip(long zip);
	public long getZip();
//	public void setCity(String city);
	public String getCity();
//	public void setState(String state);
	public String getState();
//	public void setCountry(String country);
	public String getCountry();
//	void setStreet2(String street);
	String getStreet2();
}
