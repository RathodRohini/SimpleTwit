package subscription.interfaces;

public interface MarketplaceInterface {
	public void setBaseURL(String baseURL);
	public String getBaseURL();
	public void setPartner(String partner);
	public String getPartner();
}
