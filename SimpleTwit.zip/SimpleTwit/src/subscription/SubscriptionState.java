package subscription;

public enum SubscriptionState {
	FREE_TRIAL,
	FREE_TRIAL_EXPIRED,
	ACTIVE,
	SUSPENDED,
	CANCELLED
}
