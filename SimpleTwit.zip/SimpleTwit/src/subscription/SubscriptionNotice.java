package subscription;

import org.json.JSONObject;

public class SubscriptionNotice implements EventStrategy {

	@Override
	public JSONObject handleEvent(JSONObject eventObject) {
		// TODO Auto-generated method stub
		return null;
	}

}
